require.config({
    baseUrl:"/",
    paths:{
        jquery:'libs/jquery/jquery-3.5.1.min',
        template:'libs/art-template/template-web',
        header:'js/modules/header',
        utils:'libs/utils/utils',
        log:'js/modules/log',
        swiper:'libs/swiper/swiper.min'
    },
    shim:{
      
    }
})